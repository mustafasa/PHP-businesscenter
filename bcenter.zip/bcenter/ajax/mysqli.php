<?php
$db_conx = mysqli_connect("mysql9.000webhost.com", "a3023234_jack", "Mustafa1", "a3023234_tenant");
// Evaluate the connection
if (mysqli_connect_errno()) {
    echo mysqli_connect_error();
    exit();
} else {
	echo "";
}
?>